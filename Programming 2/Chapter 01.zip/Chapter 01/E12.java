public class E12{
	public static void main(String[] args){
		System.out.println("I thought that I had wavy hair \nUntil I shaved. Instead,\nI find that I have streaight hair\nAnd a very wavy head.");
	}
}