public class E7{
	public static void main(String[] args){
		System.out.println("_______");
		System.out.println("| 0  0 |");
		System.out.println("|  ^   |");
		System.out.println("| ___  |");
		System.out.println("[______]");
	}
}