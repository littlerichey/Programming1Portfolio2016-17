public class E3 {
	public static void main(String[] args){
		int pro = 1;
		for(int i = 1; i <=10; i++){
			pro *= i;
		}
		System.out.println(pro);
	}
}