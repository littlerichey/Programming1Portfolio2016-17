public class E8{
	public static void main(String[] args){
		System.out.println("____________________________");
		System.out.println("|YYYYYYY|        |         |");
		System.out.println("|YYYYYYY|________|         |");
		System.out.println("|       |BBBBB|  |         |");
		System.out.println("|       |BBBBB|  |         |");
		System.out.println("|_______|BBBBB|__|_________|");
		System.out.println("|             |RR|YYYYYYY| |");
		System.out.println("|             |RR|YYYYYYY| |");
		System.out.println("|_____________|RR|YYYYYYY|_|");
		System.out.println("|__________________________|");
	}
}