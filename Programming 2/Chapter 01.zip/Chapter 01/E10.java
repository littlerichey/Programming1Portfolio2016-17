public class E10{
	public static void main(String[] args){
		System.out.println(" /\\_/\\    _____");
		System.out.println("( ' ' )  / It's \\");
		System.out.println("(  -  ) <   ya   |");
		System.out.println(" | | |   \\ boi  /");
		System.out.println("(__|__)   -----");
	}
}