public class E5{
	public static void main(String[] args){
		System.out.println("_________");
		System.out.println("|       |");
		System.out.println("|Addison|");
		System.out.println("|_______|");
	}
}