public class E11{
	public static void main(String[] args){
		System.out.println("Howard \nHyrum \nAddison");
	}
}