import java.util.Scanner;
import java.awt.Color;
public class E10{
	public static void main(String[] args){
	
		Color red= Color.RED.darker();
		red= red.darker();
		System.out.println(red); 
	}

}