import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.Point;
import javafx.scene.shape.Circle;
import java.awt.Graphics2D;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridLayout;
public class P9{
	public void disp(Graphics g){
		Graphics g2 = (Graphics) g;
		Point p1 = new Point(100,100);
		Point p2 = new Point(200,200);
		Point p3 = new Point(100,200);
		Point p4 = new Point(150,150);
		Point p5 = new Point(250,50);
		Circle c1 = new Circle(100,100,2);
		Circle c2 = new Circle(200,200,2);
		Circle c3 = new Circle(100,200,2);
		Circle c4 = new Circle(150,150,2);
		Circle c5 = new Circle(250,50,2);
		Line2D.Float l1 = new Line2D.Float(p1,p2);
		g2.drawCircle(c1);
	}
	public static void main(String[] args){
		JFrame f = new JFrame("lines");
		f.setSize(400,400);
		JPanel jp = new JPanel();
		f.setvisible(true);
 
		
		
	}
}